const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const read=p=>fs.readFileSync(require('node:path').join(__dirname,'..',p),'utf8');
test('original direct native surfaces are retained for both engines',()=>{
 const s=read('native/java/NativePlayerPlugin.java.tpl');
 assert.match(s,/inflate\(R.layout.codepay_video_view, parent, false\)/);
 assert.match(s,/videoParent = parent;/);
 assert.match(s,/parent.addView\(playerView, 0,/);
 assert.match(read('native/java/VlcFallback.java.tpl'),/attachViews\(layout, null, false, false\)/);
});
test('viewport applies to both surfaces and restores match-parent fullscreen',()=>{
 const s=read('native/java/NativePlayerPlugin.java.tpl');
 assert.match(s,/positionVideo\(playerView\)/); assert.match(s,/positionVideo\(vlc.videoView\(\)\)/);
 assert.match(s,/full \? ViewGroup.LayoutParams.MATCH_PARENT/);
 assert.match(s,/addOnGlobalLayoutListener\(this::applyVideoBounds\)/);
});
test('native playback keeps opaque HTML video hidden',()=>{
 assert.match(read('www/script.js'),/if \(video && engine\.native\) video\.hidden = true/);
});

test('native surface uses actual frame margins and clears stale held image on first frame',()=>{
 const s=read('native/java/NativePlayerPlugin.java.tpl');
 assert.match(s,/fp.setMargins\(left, top, 0, 0\)/);
 assert.match(s,/view.setTranslationX\(0\)/);
 assert.match(s,/clearFrameHold\(\); \/\/ never leave a captured black frame/);
 assert.match(read('www/style.css'),/html, body, .app, .tapzone \{ background: transparent !important/);
});
