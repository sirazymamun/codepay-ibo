const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const read=p=>fs.readFileSync(require('node:path').join(__dirname,'..',p),'utf8');
test('both engines use texture composition with transparent controls',()=>{
 const s=read('native/java/NativePlayerPlugin.java.tpl');
 assert.match(s,/inflate\(R.layout.codepay_video_view, host, false\)/);
 assert.match(s,/videoParent = host;/);
 assert.match(s,/android.R.id.content/);
 assert.match(s,/web.setLayerType\(android.view.View.LAYER_TYPE_NONE, null\)/);
 assert.match(s,/host.addView\(playerView, 0,/);
 assert.match(read('native/java/VlcFallback.java.tpl'),/attachViews\(layout, null, false, true\)/);
});
test('viewport applies to both surfaces and restores match-parent fullscreen',()=>{
 const s=read('native/java/NativePlayerPlugin.java.tpl');
 assert.match(s,/positionVideo\(playerView\)/); assert.match(s,/positionVideo\(vlc.videoView\(\)\)/);
 assert.match(s,/full \? ViewGroup.LayoutParams.MATCH_PARENT/);
 assert.match(s,/addOnGlobalLayoutListener\(this::applyVideoBounds\)/);
});
test('native playback keeps opaque HTML video hidden',()=>{
 assert.match(read('www/script.js'),/if \(video && engine\.native\) video\.hidden = true/);
});

test('native surface uses actual frame margins and clears stale held image on first frame',()=>{
 const s=read('native/java/NativePlayerPlugin.java.tpl');
 assert.match(s,/fp.setMargins\(left, top, 0, 0\)/);
 assert.match(s,/view.setTranslationX\(0\)/);
 assert.match(s,/clearFrameHold\(\); \/\/ never leave a captured black frame/);
 assert.match(read('www/style.css'),/html, body, .app, .tapzone \{ background: transparent !important/);
});

test('native foreground is bounded and yields to dialogs; ready reconciliation is request scoped',()=>{
 const s=read('native/java/NativePlayerPlugin.java.tpl'), js=read('www/script.js');
 assert.match(s,/videoParent.setTranslationZ\(32f\)/);
 assert.match(s,/videoParent.setVisibility\(visibility\)/);
 assert.match(s,/foregroundVideo = Boolean.TRUE.equals\(call.getBoolean\("foreground", false\)\) && hasAccess\(\) && !playbackFailed/);
 assert.match(js,/document.querySelector\("dialog\[open\]"\)/);
 assert.match(js,/result.requestId === request && request === playRequest/);
});

test('foreground does not depend on spinner or transient notifications',()=>{
 const js=read('www/script.js'), s=read('native/java/NativePlayerPlugin.java.tpl');
 assert.match(js,/bounds.foreground = !blocked && state.current >= 0 && !ui.playbackFailed;/);
 assert.match(s,/active.bringToFront\(\)/);
 assert.match(s,/videoParent.bringToFront\(\)/);
});
