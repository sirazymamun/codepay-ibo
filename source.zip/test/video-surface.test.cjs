const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const read=p=>fs.readFileSync(require('node:path').join(__dirname,'..',p),'utf8');
test('both native engines use composited texture surfaces for movable preview',()=>{
 assert.match(read('native/res/layout/codepay_video_texture.xml'),/app:surface_type="texture_view"/);
 assert.match(read('native/java/NativePlayerPlugin.java.tpl'),/inflate\(R\.layout\.codepay_video_texture, parent, false\)/);
 assert.match(read('native/java/VlcFallback.java.tpl'),/attachViews\(layout, null, false, true\)/);
});
test('native playback keeps opaque HTML video hidden',()=>{
 assert.match(read('www/script.js'),/if \(video && engine\.native\) video\.hidden = true/);
});
