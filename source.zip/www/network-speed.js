/* Real receive-throughput indicator. No speed-test requests or bandwidth estimates. */
(function (root, factory) {
  "use strict";
  const api = factory();
  if (typeof module === "object" && module.exports) module.exports = api;
  if (root && root.document) api.mount(root);
})(typeof window !== "undefined" ? window : globalThis, function () {
  "use strict";
  function presentation(bps) {
    if (!Number.isFinite(bps) || bps < 0) return {text: "— kbps", tone: "unknown"};
    const divisor = bps >= 1e9 ? 1e9 : bps >= 1e6 ? 1e6 : 1e3;
    const unit = divisor === 1e9 ? "Gbps" : divisor === 1e6 ? "Mbps" : "kbps";
    return {text: (bps / divisor).toFixed(2).replace(/\.00$/, "") + " " + unit,
      tone: bps <= 5e6 ? "slow" : bps <= 1e7 ? "medium" : "fast"};
  }
  function sampleRate(previous, current) {
    if (!current || current.supported !== true || !Number.isFinite(current.receivedBytes) ||
        !Number.isFinite(current.elapsedMs) || current.receivedBytes < 0) return null;
    if (!previous || previous.supported !== true) return null;
    const bytes = current.receivedBytes - previous.receivedBytes;
    const ms = current.elapsedMs - previous.elapsedMs;
    return bytes >= 0 && ms > 0 ? bytes * 8000 / ms : null;
  }
  function createController(options) {
    const clock = options.now || Date.now;
    const later = options.setTimeout || setTimeout;
    const cancel = options.clearTimeout || clearTimeout;
    let menu = false, visible = false, suspended = false, expires = 0;
    let poll = null, hide = null, generation = 0, previous = null, disposed = false;
    function stopPoll() { generation++; cancel(poll); poll = null; previous = null; }
    function hideNow() { cancel(hide); hide = null; visible = false; expires = 0; stopPoll(); options.visibility(false); }
    function startPoll() {
      if (!visible || suspended || disposed || poll !== null) return;
      const request = generation;
      poll = later(function () {
        poll = null;
        Promise.resolve().then(options.read).then(function (current) {
          if (request !== generation || !visible || suspended || disposed) return;
          options.paint(presentation(sampleRate(previous, current)));
          previous = current && current.supported === true ? current : null;
        }).catch(function () {
          if (request === generation) { previous = null; options.paint(presentation(null)); }
        }).then(function () {
          if (request === generation && visible && !suspended && !disposed) {
            poll = later(function () { poll = null; startPoll(); }, 1000);
          }
        });
      }, 0);
    }
    function setMenu(open) {
      if (disposed || menu === !!open) return;
      menu = !!open;
      cancel(hide); hide = null;
      if (menu) {
        expires = 0;
        if (!visible) {visible = true; options.paint(presentation(null)); options.visibility(true);}
        startPoll();
      } else if (visible) {
        expires = clock() + 60000;
        hide = later(hideNow, 60000);
      }
    }
    function setSuspended(value) {
      suspended = !!value; stopPoll();
      if (!suspended && !disposed) {
        if (!menu && expires && clock() >= expires) hideNow();
        else startPoll();
      }
    }
    return {setMenu, setSuspended, dispose: function () {disposed = true; hideNow();},
      state: function () {return {menu, visible, expires};}};
  }
  function mount(root) {
    const document = root.document, badge = document.getElementById("networkSpeed");
    if (!badge || !root.MutationObserver) return;
    let plugin = null;
    try {
      const cap = root.Capacitor;
      if (cap && cap.isNativePlatform && cap.isNativePlatform())
        plugin = cap.registerPlugin ? cap.registerPlugin("NativePlayer") : cap.Plugins && cap.Plugins.NativePlayer;
    } catch (_) { /* browser/unsupported host is shown honestly as unavailable */ }
    const homeSlot = badge.parentNode;
    const actionSlot = document.querySelector('.ibo-preview-actions');
    function position() {
      const home = document.getElementById('iboHome');
      const overlay = document.querySelector('.overlay');
      const browsing = actionSlot && home && home.hidden && overlay && !overlay.hidden && !document.body.classList.contains('empty');
      if (browsing) { if (badge.parentNode !== actionSlot) actionSlot.insertBefore(badge, actionSlot.firstChild); }
      else if (badge.parentNode !== homeSlot) homeSlot.appendChild(badge);
      badge.style.right = ''; badge.style.bottom = '';
      const search = document.getElementById('btnSearch');
      const channels = document.querySelector('.pane.channels');
      if (browsing && search && channels && root.innerWidth >= root.innerHeight) {
        const width = channels.getBoundingClientRect().right - search.getBoundingClientRect().left;
        if (width > 0) search.style.setProperty('--ibo-search-width', width + 'px');
      }
    }
    const controller = createController({
      read: function () {return plugin && plugin.getNetworkTraffic ? plugin.getNetworkTraffic() : Promise.resolve({supported: false});},
      visibility: function (shown) {badge.hidden = !shown; if (shown) position();},
      paint: function (value) {badge.textContent = value.text; badge.dataset.speedTone = value.tone;}
    });
    function sync() {
      const open = document.body.classList.contains("channel-menu-open") && !document.body.classList.contains("empty");
      controller.setMenu(open); position();
    }
    const observer = new root.MutationObserver(sync);
    observer.observe(document.body, {attributes: true, attributeFilter: ["class"]});
    const home = document.getElementById("iboHome"), overlay = document.querySelector(".overlay");
    if (home) observer.observe(home, {attributes:true, attributeFilter:["hidden"]});
    if (overlay) observer.observe(overlay, {attributes:true, attributeFilter:["hidden", "class"]});
    document.addEventListener("visibilitychange", function () {controller.setSuspended(document.hidden);});
    root.addEventListener("resize", position);
    root.addEventListener("pagehide", function () {controller.setSuspended(true);});
    root.addEventListener("pageshow", function () {controller.setSuspended(document.hidden);});
    sync(); controller.setSuspended(document.hidden);
  }
  return {presentation, sampleRate, createController, mount};
});
