window.ACTIVE_CODE_CONFIG = Object.freeze({ apiBase: "https://YOUR_DOMAIN/activation/api.php" });
