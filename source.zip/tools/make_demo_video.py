#!/usr/bin/env python3
"""Generate deterministic, credential-free test media for instrumentation APK only."""
import argparse, pathlib, subprocess, json
CASES = [('sd',720,480,'libx264'),('hd',1280,720,'libx264'),('fhd',1920,1080,'libx264'),('uhd',3840,2160,'libx264'),('uhd-hevc',3840,2160,'libx265')]
def main():
    p=argparse.ArgumentParser(); p.add_argument('directory',type=pathlib.Path); a=p.parse_args(); a.directory.mkdir(parents=True,exist_ok=True)
    for name,w,h,codec in CASES:
        out=a.directory/(name+'.mp4')
        extra=['-preset','ultrafast','-threads','2'] if codec=='libx264' else ['-preset','ultrafast','-x265-params','pools=2:frame-threads=2:log-level=error','-tag:v','hvc1']
        subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-y','-f','lavfi','-i',f'testsrc2=size={w}x{h}:rate=24','-f','lavfi','-i','sine=frequency=440:sample_rate=48000','-t','8','-c:v',codec,*extra,'-pix_fmt','yuv420p','-crf','28','-c:a','aac','-b:a','96k','-movflags','+faststart',str(out)],check=True)
        data=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_streams','-of','json',str(out)])); v=next(s for s in data['streams'] if s['codec_type']=='video'); assert (v['width'],v['height'],v['codec_name'])==(w,h,'h264' if codec=='libx264' else 'hevc'); assert any(s['codec_type']=='audio' for s in data['streams']); subprocess.run(['ffmpeg','-v','error','-threads','2','-i',str(out),'-f','null','-'],check=True); print('PASS demo source decode:',name,flush=True)
if __name__=='__main__': main()
