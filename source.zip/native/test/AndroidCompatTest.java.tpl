package __PACKAGE__;
import android.webkit.WebView;
import androidx.test.core.app.ActivityScenario;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import org.junit.Test;
import org.junit.runner.RunWith;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import static org.junit.Assert.*;

/** Real WebView/native-bridge smoke tests; provider codecs need separate device tests. */
@RunWith(AndroidJUnit4.class)
public class AndroidCompatTest {
 @Test public void vlcNativeLibraryLoads() {
  android.content.Context context=androidx.test.platform.app.InstrumentationRegistry.getInstrumentation().getTargetContext();
  org.videolan.libvlc.LibVLC engine=new org.videolan.libvlc.LibVLC(context,new java.util.ArrayList<String>());
  engine.release();
 }
 @Test public void firstRunAndCodeDialogRender() throws Exception {
  android.content.Context context=androidx.test.platform.app.InstrumentationRegistry.getInstrumentation().getTargetContext();
  String agent=android.webkit.WebSettings.getDefaultUserAgent(context);
  java.util.regex.Matcher chrome=java.util.regex.Pattern.compile("(?:Chrome|Chromium)/(\\d+)").matcher(agent);
  // Android 7 images may expose an old WebView UA without a Chrome/Chromium
  // version.  Unknown must not be treated as modern: the production app needs
  // WebView 60+, while the independent VLC native-library test still runs.
  boolean supportedWebView=chrome.find() && Integer.parseInt(chrome.group(1))>=60;
  org.junit.Assume.assumeTrue("UI coverage pending: update the emulator WebView to Chrome 60+",supportedWebView);

  try(ActivityScenario<MainActivity> scenario=ActivityScenario.launch(MainActivity.class)) {
   String result="";
   for(int i=0;i<30;i++) {
    CountDownLatch latch=new CountDownLatch(1);String[] value={""};
    scenario.onActivity(activity->{
     WebView web=activity.getBridge().getWebView();
     web.evaluateJavascript("(function(){try{var b=document.getElementById('btnWelcomeAdd'),app=document.getElementById('app'),home=document.getElementById('iboHome'),brand=document.querySelector('.ibo-brand img'),overlay=document.getElementById('overlay');if(!b||!app||!home||!brand||!overlay)return 'not-ready: missing UI';var a=app.getBoundingClientRect();if(a.width<innerWidth*.98||a.height<innerHeight*.98)return 'layout-error: viewport';var wasHidden=overlay.hidden,wasEmpty=document.body.classList.contains('empty'),wasHome=overlay.classList.contains('ibo-home-open');try{overlay.hidden=false;document.body.classList.remove('empty');overlay.classList.remove('ibo-home-open');var g=document.querySelector('.groups').getBoundingClientRect(),c=document.querySelector('.channels').getBoundingClientRect(),m=document.querySelector('.bar').getBoundingClientRect(),logo=brand.getBoundingClientRect();if(g.width<innerWidth*.15||c.width<innerWidth*.25||g.height<innerHeight*.5||c.height<innerHeight*.5)return 'layout-error: catalogue columns';if(m.left<0||m.right>innerWidth+1||m.top<0||m.bottom>innerHeight)return 'layout-error: header';if(logo.width<=0||logo.height<=0||!brand.complete||!brand.naturalWidth)return 'not-ready: logo';}finally{overlay.hidden=wasHidden;document.body.classList.toggle('empty',wasEmpty);overlay.classList.toggle('ibo-home-open',wasHome);}if(!b.getBoundingClientRect().width)return 'not-ready: activation button';var d=document.getElementById('dlg');if(!d.open)b.click();var input=document.getElementById('activationCode');return d.open&&input&&input.getBoundingClientRect().width>0?'ready':'not-ready: activation dialog';}catch(e){return 'javascript-error: '+String(e);}})()",v->{value[0]=v;latch.countDown();});
    });
    assertTrue("WebView response timed out",latch.await(5,TimeUnit.SECONDS));result=value[0];
    if("\"ready\"".equals(result))break;
    Thread.sleep(1000);
   }
   assertEquals("App viewport, category/channel columns and activation dialog must render; inspect returned layout error", "\"ready\"", result);
  }
 }
}
