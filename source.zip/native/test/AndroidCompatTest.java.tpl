package __PACKAGE__;
import android.webkit.WebView;
import androidx.test.core.app.ActivityScenario;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import org.junit.Test;
import org.junit.runner.RunWith;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import static org.junit.Assert.*;

/** Real WebView/native-bridge smoke tests; provider codecs need separate device tests. */
@RunWith(AndroidJUnit4.class)
public class AndroidCompatTest {
 @Test public void vlcNativeLibraryLoads() {
  android.content.Context context=androidx.test.platform.app.InstrumentationRegistry.getInstrumentation().getTargetContext();
  org.videolan.libvlc.LibVLC engine=new org.videolan.libvlc.LibVLC(context,new java.util.ArrayList<String>());
  engine.release();
 }
 @Test public void firstRunAndCodeDialogRender() throws Exception {
  android.content.Context context=androidx.test.platform.app.InstrumentationRegistry.getInstrumentation().getTargetContext();
  String agent=android.webkit.WebSettings.getDefaultUserAgent(context);
  java.util.regex.Matcher chrome=java.util.regex.Pattern.compile("(?:Chrome|Chromium)/(\\d+)").matcher(agent);
  // Android 7 images may expose an old WebView UA without a Chrome/Chromium
  // version.  Unknown must not be treated as modern: the production app needs
  // WebView 60+, while the independent VLC native-library test still runs.
  boolean supportedWebView=chrome.find() && Integer.parseInt(chrome.group(1))>=60;
  org.junit.Assume.assumeTrue("UI coverage pending: update the emulator WebView to Chrome 60+",supportedWebView);

  try(ActivityScenario<MainActivity> scenario=ActivityScenario.launch(MainActivity.class)) {
   String result="";
   for(int i=0;i<30;i++) {
    CountDownLatch latch=new CountDownLatch(1);String[] value={""};
    scenario.onActivity(activity->{
     WebView web=activity.getBridge().getWebView();
     web.evaluateJavascript("(function(){try{var b=document.querySelector('#iboHome [data-home-action=btnOpen]'),app=document.getElementById('app'),home=document.getElementById('iboHome'),brand=document.querySelector('.ibo-brand img'),overlay=document.getElementById('overlay');if(!b||!app||!home||!brand||!overlay)return 'not-ready: missing UI';var a=app.getBoundingClientRect();if(a.width<innerWidth*.98||a.height<innerHeight*.98)return 'layout-error: viewport';var wasHidden=overlay.hidden,wasEmpty=document.body.classList.contains('empty'),wasHome=overlay.classList.contains('ibo-home-open');try{overlay.hidden=false;document.body.classList.remove('empty');overlay.classList.remove('ibo-home-open');var g=document.querySelector('.groups').getBoundingClientRect(),c=document.querySelector('.channels').getBoundingClientRect(),m=document.querySelector('.bar').getBoundingClientRect(),logo=brand.getBoundingClientRect();if(g.width<innerWidth*.15||c.width<innerWidth*.25||g.height<innerHeight*.5||c.height<innerHeight*.5)return 'layout-error: catalogue columns';if(m.left<0||m.right>innerWidth+1||m.top<0||m.bottom>innerHeight)return 'layout-error: header';if(logo.width<=0||logo.height<=0||!brand.complete||!brand.naturalWidth)return 'not-ready: logo';}finally{overlay.hidden=wasHidden;document.body.classList.toggle('empty',wasEmpty);overlay.classList.toggle('ibo-home-open',wasHome);}if(!b.getBoundingClientRect().width)return 'not-ready: activation button';var d=document.getElementById('dlg');if(!d.open)b.click();var input=document.getElementById('activationCode');return d.open&&input&&input.getBoundingClientRect().width>0?'ready':'not-ready: activation dialog';}catch(e){return 'javascript-error: '+String(e);}})()",v->{value[0]=v;latch.countDown();});
    });
    assertTrue("WebView response timed out",latch.await(5,TimeUnit.SECONDS));result=value[0];
    if("\"ready\"".equals(result))break;
    Thread.sleep(1000);
   }
   assertEquals("App viewport, category/channel columns and activation dialog must render; inspect returned layout error", "\"ready\"", result);
  }
 }

 // Test-only reflection exercises the actual production plugin and renderer without
 // contacting a subscription server. No activation bypass is shipped in the app.
 private static java.lang.reflect.Field field(String name) throws Exception {
  java.lang.reflect.Field f=NativePlayerPlugin.class.getDeclaredField(name); f.setAccessible(true); return f;
 }
 private static void invoke(NativePlayerPlugin p,String name,Class<?>[] types,Object... args) throws Exception {
  java.lang.reflect.Method m=NativePlayerPlugin.class.getDeclaredMethod(name,types);m.setAccessible(true);m.invoke(p,args);
 }
 private void demo(String name) throws Exception {
  androidx.test.platform.app.InstrumentationRegistry.getInstrumentation().waitForIdleSync();
  android.app.Instrumentation ins=androidx.test.platform.app.InstrumentationRegistry.getInstrumentation();
  java.io.File clip=new java.io.File(ins.getTargetContext().getCacheDir(),name+".mp4");
  try(java.io.InputStream in=ins.getContext().getAssets().open("demo/"+name+".mp4");java.io.OutputStream out=new java.io.FileOutputStream(clip)) {
   byte[] buf=new byte[65536];int n;while((n=in.read(buf))!=-1)out.write(buf,0,n);
  }
  try(ActivityScenario<MainActivity> scenario=ActivityScenario.launch(MainActivity.class)) {
   Thread.sleep(2500);
   NativePlayerPlugin[] plugin={null};
   scenario.onActivity(a->{try {
    plugin[0]=(NativePlayerPlugin)a.getBridge().getPlugin("NativePlayer").getInstance();
    NativePlayerPlugin p=plugin[0];
    assertNotNull("Native PlayerView",field("playerView").get(p));
    field("accessUntil").setLong(p,android.os.SystemClock.elapsedRealtime()+120000);
    field("playbackFailed").setBoolean(p,false);
    invoke(p,"beginExoDeadline",new Class<?>[0]);
    invoke(p,"startPlayback",new Class<?>[]{String.class,java.util.Map.class,int.class,int.class},android.net.Uri.fromFile(clip).toString(),new java.util.HashMap<String,String>(),StreamFormatDetector.AUTO,0);
    androidx.media3.exoplayer.ExoPlayer exo=(androidx.media3.exoplayer.ExoPlayer)field("player").get(p);
    exo.setRepeatMode(androidx.media3.common.Player.REPEAT_MODE_ONE);
    // Keep the real WebView present; verify the native player can cover it.
    a.getBridge().getWebView().setVisibility(android.view.View.VISIBLE);
   }catch(Exception e){throw new AssertionError(e);}});
   for(boolean preview:new boolean[]{true,false}) {
    boolean passed=false;int[] previous=null;long until=android.os.SystemClock.elapsedRealtime()+30000;
    while(android.os.SystemClock.elapsedRealtime()<until) {
     final boolean[] ready={false};final int[] area=new int[4];
     scenario.onActivity(a->{try {
      NativePlayerPlugin p=plugin[0];
      field("foregroundVideo").setBoolean(p,true);
      field("videoX").setDouble(p,preview?.50:0);field("videoY").setDouble(p,preview?.10:0);
      field("videoW").setDouble(p,preview?.48:1);field("videoH").setDouble(p,preview?.55:1);
      invoke(p,"applyVideoBounds",new Class<?>[0]);
      androidx.media3.exoplayer.ExoPlayer exo=(androidx.media3.exoplayer.ExoPlayer)field("player").get(p);
      boolean vlc=field("vlcActive").getBoolean(p);
      android.view.View v=vlc?((VlcFallback)field("vlc").get(p)).videoView():(android.view.View)field("playerView").get(p);
      int[] xy=new int[2];v.getLocationOnScreen(xy);area[0]=xy[0];area[1]=xy[1];area[2]=v.getWidth();area[3]=v.getHeight();
      ready[0]=vlc?((VlcFallback)field("vlc").get(p)).isPlaying():exo!=null&&exo.isPlaying()&&field("exoRenderedFrame").getBoolean(p);
     }catch(Exception e){throw new AssertionError(e);}});
     Thread.sleep(350);
     if(!ready[0])continue;
     android.graphics.Bitmap shot=ins.getUiAutomation().takeScreenshot();
     if(shot==null)continue;
     int red=0,green=0,blue=0,total=0,changed=0;int[] current=new int[361];
     for(int j=1;j<20;j++)for(int i=1;i<20;i++) {
      int x=area[0]+area[2]*i/20,y=area[1]+area[3]*j/20;
      if(x<0||y<0||x>=shot.getWidth()||y>=shot.getHeight())continue;
      int c=shot.getPixel(x,y),r=android.graphics.Color.red(c),g=android.graphics.Color.green(c),b=android.graphics.Color.blue(c);current[total]=c; if(previous!=null){int old=previous[total];if(Math.abs(r-android.graphics.Color.red(old))+Math.abs(g-android.graphics.Color.green(old))+Math.abs(b-android.graphics.Color.blue(old))>60)changed++;}total++;
      if(r>100&&r>g+45&&r>b+45)red++;
      if(g>100&&g>r+45&&g>b+45)green++;
      if(b>100&&b>r+45&&b>g+45)blue++;
     }
     shot.recycle();
     // A frame counter, black screen, or plain maroon UI cannot satisfy three colours.
     if(total>200&&red>=12&&green>=12&&blue>=12){if(previous!=null&&changed>=4){passed=true;break;}previous=current;}
    }
    assertTrue(name+" "+(preview?"preview":"fullscreen")+": real screen must show RGB test pattern",passed);
   }
  } finally {clip.delete();}
 }
 @Test public void demoSd() throws Exception {demo("sd");}
 @Test public void demoHd() throws Exception {demo("hd");}
 @Test public void demoFhd() throws Exception {demo("fhd");}
 @Test public void demoUhd() throws Exception {demo("uhd");}
 @Test public void demoUhdHevc() throws Exception {demo("uhd-hevc");}
}
